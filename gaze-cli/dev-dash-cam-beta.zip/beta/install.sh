mkdir ~/.devdashcam/
cp ./se_license_key_process_devdashcam ~/.devdashcam/se_license_key_process_devdashcam
