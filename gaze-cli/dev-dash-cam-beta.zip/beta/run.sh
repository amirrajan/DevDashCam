LD_LIBRARY_PATH=./lib ./Dev\ Dash\ Cam
